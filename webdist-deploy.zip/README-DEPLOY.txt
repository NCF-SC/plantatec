﻿# webdist — pasta para deploy web

## Senha de acesso (gate casual)
Plantatec2026

- Barreira leve via `gate.js` + `sessionStorage` (não é segurança real).
- `app.js` só é carregado depois da senha correta.
- Não há `app.js` limpo nesta pasta — apenas ofuscado.

## Conteúdo
- index.html, styles.css, gate.js, app.js (obfuscado)
