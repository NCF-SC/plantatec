﻿/**
 * Casual access gate (not real security).
 * Password: Plantatec2026
 * Unlock persists for the browser tab via sessionStorage.
 */
(function () {
  var KEY = "plantatec_web_unlock";
  var PASS = "Plantatec2026";

  function loadApp() {
    if (document.querySelector('script[data-plantatec-app]')) return;
    var s = document.createElement("script");
    s.src = "app.js";
    s.defer = true;
    s.setAttribute("data-plantatec-app", "1");
    document.body.appendChild(s);
  }

  function unlock() {
    try { sessionStorage.setItem(KEY, "1"); } catch (e) {}
    var gate = document.getElementById("webAccessGate");
    if (gate) gate.remove();
    document.documentElement.classList.remove("web-gated");
    loadApp();
  }

  function isUnlocked() {
    try { return sessionStorage.getItem(KEY) === "1"; } catch (e) { return false; }
  }

  if (isUnlocked()) {
    document.addEventListener("DOMContentLoaded", loadApp);
    if (document.readyState !== "loading") loadApp();
    return;
  }

  document.documentElement.classList.add("web-gated");

  function mountGate() {
    if (document.getElementById("webAccessGate")) return;
    var wrap = document.createElement("div");
    wrap.id = "webAccessGate";
    wrap.setAttribute("role", "dialog");
    wrap.setAttribute("aria-modal", "true");
    wrap.setAttribute("aria-label", "Acesso Plantatec");
    wrap.innerHTML =
      '<div class="web-gate-card">' +
      '<p class="brand-mark">PLANTATEC</p>' +
      "<h2>Acesso restrito</h2>" +
      "<p>Digite a senha para abrir o app.</p>" +
      '<label>Senha<input type="password" id="webGatePassword" autocomplete="current-password" /></label>' +
      '<p id="webGateError" class="web-gate-error" hidden>Senha incorreta.</p>' +
      '<button type="button" id="webGateBtn" class="btn primary">Entrar</button>' +
      "</div>";
    document.body.appendChild(wrap);

    var input = document.getElementById("webGatePassword");
    var err = document.getElementById("webGateError");
    var btn = document.getElementById("webGateBtn");

    function tryUnlock() {
      if (input.value === PASS) {
        unlock();
      } else {
        err.hidden = false;
        input.focus();
        input.select();
      }
    }

    btn.addEventListener("click", tryUnlock);
    input.addEventListener("keydown", function (e) {
      if (e.key === "Enter") tryUnlock();
    });
    setTimeout(function () { input.focus(); }, 50);
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", mountGate);
  } else {
    mountGate();
  }
})();
